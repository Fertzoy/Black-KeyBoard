package com.example.blankkeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class BlankKeyboardService : InputMethodService() {
    override fun onCreateInputView(): View = BlankKeyboardView(this)
}

private enum class Kind { CHAR, SHIFT, DEL, SPACE, ENTER, MODE, GAP }

private class Key(val label: String, val weight: Float, val kind: Kind) {
    val rect = RectF()
}

class BlankKeyboardView(private val service: InputMethodService) : View(service) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val colorBg = Color.BLACK
    private val colorChar = Color.parseColor("#2B2B2D")
    private val colorFunc = Color.parseColor("#1A1A1C")
    private val colorPressed = Color.parseColor("#55555A")
    private val colorShiftOn = Color.parseColor("#8E8E93")
    private val colorShiftLock = Color.WHITE

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var numbers = false
    private var shift = 0 // 0 = выкл, 1 = одна заглавная, 2 = caps lock
    private var lastShiftTap = 0L
    private var rows: List<List<Key>> = buildRows()
    private var pressed: Key? = null

    private val handler = Handler(Looper.getMainLooper())
    private val repeatDelete = object : Runnable {
        override fun run() {
            service.sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            handler.postDelayed(this, 50)
        }
    }

    private fun chars(s: String, w: Float = 1f) = s.map { Key(it.toString(), w, Kind.CHAR) }

    private fun buildRows(): List<List<Key>> =
        if (!numbers) listOf(
            chars("qwertyuiop"),
            listOf(Key("", 0.5f, Kind.GAP)) + chars("asdfghjkl") + Key("", 0.5f, Kind.GAP),
            listOf(Key("", 1.25f, Kind.SHIFT), Key("", 0.25f, Kind.GAP)) +
                chars("zxcvbnm") +
                listOf(Key("", 0.25f, Kind.GAP), Key("", 1.25f, Kind.DEL)),
            listOf(Key("", 2.2f, Kind.MODE), Key(" ", 5.3f, Kind.SPACE), Key("", 2.5f, Kind.ENTER))
        ) else listOf(
            chars("1234567890"),
            chars("-/:;()$&@\""),
            listOf(Key("", 1.5f, Kind.GAP)) + chars(".,?!'", 1.4f) +
                listOf(Key("", 0.25f, Kind.GAP), Key("", 1.25f, Kind.DEL)),
            listOf(Key("", 2.2f, Kind.MODE), Key(" ", 5.3f, Kind.SPACE), Key("", 2.5f, Kind.ENTER))
        )

    private fun layoutKeys(w: Int) {
        val side = dp(3f)
        val unit = (w - 2 * side) / 10f
        val rowH = dp(50f)
        val top = dp(6f)
        rows.forEachIndexed { i, row ->
            var x = side
            for (k in row) {
                val cell = unit * k.weight
                k.rect.set(
                    x + dp(3f), top + i * rowH + dp(5f),
                    x + cell - dp(3f), top + (i + 1) * rowH - dp(5f)
                )
                x += cell
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            MeasureSpec.getSize(widthMeasureSpec),
            dp(4 * 50f + 12f).toInt()
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        layoutKeys(w)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(colorBg)
        val r = dp(6f)
        for (row in rows) for (k in row) {
            if (k.kind == Kind.GAP) continue
            paint.color = when {
                k === pressed -> colorPressed
                k.kind == Kind.SHIFT && shift == 1 -> colorShiftOn
                k.kind == Kind.SHIFT && shift == 2 -> colorShiftLock
                k.kind == Kind.CHAR || k.kind == Kind.SPACE -> colorChar
                else -> colorFunc
            }
            canvas.drawRoundRect(k.rect, r, r, paint)
        }
    }

    private fun findKey(x: Float, y: Float): Key? {
        val hit = RectF()
        for (row in rows) for (k in row) {
            if (k.kind == Kind.GAP) continue
            hit.set(k.rect)
            hit.inset(-dp(3f), -dp(5f))
            if (hit.contains(x, y)) return k
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = findKey(e.x, e.y)
                if (pressed != null) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (pressed?.kind == Kind.DEL) {
                    service.sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                    handler.postDelayed(repeatDelete, 400)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val k = findKey(e.x, e.y)
                if (k !== pressed) {
                    handler.removeCallbacks(repeatDelete)
                    pressed = k
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeatDelete)
                val k = pressed
                pressed = null
                if (k != null && k.kind != Kind.DEL) handleKey(k)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeatDelete)
                pressed = null
                invalidate()
            }
        }
        return true
    }

    private fun handleKey(k: Key) {
        val ic = service.currentInputConnection
        when (k.kind) {
            Kind.CHAR -> {
                val t = if (shift > 0) k.label.uppercase() else k.label
                ic?.commitText(t, 1)
                if (shift == 1) shift = 0
            }
            Kind.SPACE -> ic?.commitText(" ", 1)
            Kind.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && now - lastShiftTap < 400 -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShiftTap = now
            }
            Kind.MODE -> {
                numbers = !numbers
                rows = buildRows()
                layoutKeys(width)
            }
            Kind.ENTER -> {
                val ei = service.currentInputEditorInfo
                val opts = ei?.imeOptions ?: 0
                val action = opts and EditorInfo.IME_MASK_ACTION
                if (ei != null &&
                    (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
                    action != EditorInfo.IME_ACTION_NONE &&
                    action != EditorInfo.IME_ACTION_UNSPECIFIED
                ) {
                    ic?.performEditorAction(action)
                } else {
                    service.sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
                }
            }
            else -> {}
        }
    }
}
